
import axios from 'axios';

const BASE_URL = 'https://phimapi.com';
const CACHE_KEY_PREFIX = 'motphim_v2_';
const CACHE_DURATION = 1000 * 60 * 60; // 1 giờ

const fetchWithCache = async (url: string, priority = false) => {
  const cached = localStorage.getItem(CACHE_KEY_PREFIX + url);
  
  // Trả về dữ liệu cache ngay lập tức nếu có
  if (cached) {
    const { data, timestamp } = JSON.parse(cached);
    if (Date.now() - timestamp < CACHE_DURATION) {
      // Nếu là ưu tiên cao, ta vẫn trả về ngay nhưng vẫn có thể fetch ngầm để cập nhật
      if (!priority) return data;
      // Fetch ngầm (Stale-while-revalidate)
      axios.get(url).then(res => {
        localStorage.setItem(CACHE_KEY_PREFIX + url, JSON.stringify({
          data: res.data,
          timestamp: Date.now()
        }));
      }).catch(() => {});
      return data;
    }
  }

  const response = await axios.get(url);
  localStorage.setItem(CACHE_KEY_PREFIX + url, JSON.stringify({
    data: response.data,
    timestamp: Date.now()
  }));
  return response.data;
};

export const getLatestMovies = (page: number = 1) => 
  fetchWithCache(`${BASE_URL}/danh-sach/phim-moi-cap-nhat?page=${page}`);

export const getMovieDetail = (slug: string) => 
  fetchWithCache(`${BASE_URL}/phim/${slug}`, true);

export const prefetchMovie = (slug: string) => {
  getMovieDetail(slug).catch(() => {});
};

export const getImageUrl = (path: string) => {
    if (!path) return 'https://picsum.photos/400/600?grayscale';
    if (path.startsWith('http')) return path;
    return `https://phimimg.com/${path}`;
};

export const searchMovies = (keyword: string, limit: number = 20) => 
  fetchWithCache(`${BASE_URL}/v1/api/tim-kiem?keyword=${keyword}&limit=${limit}`);

export const getMoviesByCategory = (categorySlug: string, page: number = 1) => 
  fetchWithCache(`https://ophim1.com/v1/api/the-loai/${categorySlug}?page=${page}`);

export const getMoviesByType = (type: string, page: number = 1) => 
  fetchWithCache(`${BASE_URL}/v1/api/danh-sach/${type}?page=${page}`);
