
import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { MovieItem } from '../types';
import { getImageUrl, prefetchMovie } from '../api/ophim';

interface MovieCardProps {
  movie: MovieItem;
}

const MovieCard: React.FC<MovieCardProps> = React.memo(({ movie }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const langLower = movie.lang?.toLowerCase() || '';
  const isLongTieng = langLower.includes('lồng tiếng');
  const isThuyetMinh = langLower.includes('thuyết minh');
  const imageSrc = getImageUrl(movie.poster_url || movie.thumb_url);

  // Tải trước dữ liệu khi hover
  const handleMouseEnter = useCallback(() => {
    prefetchMovie(movie.slug);
  }, [movie.slug]);

  return (
    <Link 
      to={`/movie/${movie.slug}`} 
      onMouseEnter={handleMouseEnter}
      className="group relative flex flex-col gap-4"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden rounded-[1.5rem] bg-[#0d0d0d] border border-white/5 shadow-2xl transition-all duration-500 group-hover:border-[#ff2e63]/30 group-hover:shadow-[0_0_30px_rgba(255,46,99,0.15)] group-hover:-translate-y-2">
        {!isLoaded && <div className="absolute inset-0 bg-white/5 animate-pulse"></div>}
        
        <img
          src={imageSrc}
          alt={movie.name}
          className={`h-full w-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:rotate-1 group-hover:brightness-50 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setIsLoaded(true)}
          loading="lazy"
          decoding="async"
          onError={(e) => { (e.target as HTMLImageElement).src = "https://picsum.photos/400/600?grayscale"; }}
        />
        
        <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
           {movie.quality && (
             <span className="bg-black/60 backdrop-blur-md text-white text-[8px] font-black px-2.5 py-1 rounded-lg border border-white/10 uppercase tracking-widest">
                {movie.quality}
             </span>
           )}
           {movie.lang && (
             <span className={`text-[8px] font-black px-2.5 py-1 rounded-lg border border-white/10 tracking-widest uppercase ${isLongTieng ? 'bg-green-500/80 text-white' : isThuyetMinh ? 'bg-blue-500/80 text-white' : 'bg-black/60 text-white'}`}>
                {movie.lang}
             </span>
           )}
        </div>

        {movie.episode_current && (
           <div className="absolute top-4 right-4 bg-[#ff2e63] text-white text-[8px] font-black px-2.5 py-1 rounded-lg shadow-lg uppercase tracking-widest">
              {movie.episode_current}
           </div>
        )}

        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 scale-50 group-hover:scale-100">
            <div className="w-14 h-14 bg-[#ff2e63] rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,46,99,0.6)]">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                 </svg>
            </div>
        </div>
      </div>

      <div className="flex flex-col gap-1.5 px-2">
        <h3 className="text-[13px] font-bold text-white/90 line-clamp-1 group-hover:text-[#ff2e63] transition-colors duration-300 tracking-tight">
          {movie.name}
        </h3>
        <div className="flex items-center justify-between">
            <span className="text-[10px] text-white/30 font-bold uppercase tracking-widest truncate max-w-[70%]">{movie.origin_name}</span>
            <span className="text-[10px] text-[#ff2e63]/60 font-black">{movie.year}</span>
        </div>
      </div>
    </Link>
  );
});

MovieCard.displayName = 'MovieCard';

export default MovieCard;
