
import React from 'react';

export const CardSkeleton = () => (
  <div className="flex flex-col gap-4 animate-pulse">
    <div className="aspect-[2/3] w-full bg-white/5 rounded-[1.5rem] border border-white/5"></div>
    <div className="h-4 bg-white/5 rounded-full w-3/4"></div>
    <div className="h-3 bg-white/5 rounded-full w-1/2"></div>
  </div>
);

export const HeroSkeleton = () => (
  <div className="h-[85vh] w-full bg-white/5 rounded-[3rem] animate-pulse flex flex-col justify-center px-24 gap-8">
    <div className="h-4 bg-white/10 rounded-full w-48"></div>
    <div className="h-24 bg-white/10 rounded-3xl w-3/4"></div>
    <div className="h-6 bg-white/10 rounded-full w-1/2"></div>
    <div className="flex gap-4">
      <div className="h-14 bg-white/10 rounded-2xl w-48"></div>
      <div className="h-14 bg-white/10 rounded-2xl w-32"></div>
    </div>
  </div>
);

export const SectionSkeleton = ({ title }: { title: string }) => (
  <section className="flex flex-col gap-8">
    <div className="flex items-end justify-between border-b border-white/5 pb-8">
      <div className="h-10 bg-white/5 rounded-xl w-64"></div>
    </div>
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
      {[...Array(6)].map((_, i) => <CardSkeleton key={i} />)}
    </div>
  </section>
);
