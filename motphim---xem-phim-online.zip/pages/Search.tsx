
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { searchMovies } from '../api/ophim';
import MovieCard from '../components/MovieCard';
import { MovieItem } from '../types';

const Search: React.FC = () => {
  const [movies, setMovies] = useState<MovieItem[]>([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const query = new URLSearchParams(location.search).get('q') || '';

  useEffect(() => {
    const fetchResults = async () => {
      if (!query) return;
      setLoading(true);
      try {
        const data = await searchMovies(query);
        if (data.status && data.data.items) {
          setMovies(data.data.items);
        }
      } catch (error) {
        console.error('Error searching movies:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [query]);

  return (
    <div className="flex flex-col gap-8">
      <h2 className="text-2xl font-bold flex items-center gap-3">
        <span className="w-2 h-8 bg-[#ff2e63] rounded-full"></span>
        Kết quả tìm kiếm cho: <span className="text-[#ff2e63]">"{query}"</span>
      </h2>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-12 h-12 border-4 border-[#ff2e63] border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : movies.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {movies.map((movie) => (
            <MovieCard key={movie.slug} movie={movie} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white/5 rounded-2xl border border-white/5">
          <p className="text-gray-400">Rất tiếc, chúng tôi không tìm thấy phim bạn yêu cầu.</p>
          <p className="text-sm text-gray-500 mt-2">Hãy thử tìm kiếm với từ khóa khác.</p>
        </div>
      )}
    </div>
  );
};

export default Search;
