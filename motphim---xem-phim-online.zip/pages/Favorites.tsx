
import React, { useEffect, useState } from 'react';
import { getMovieDetail } from '../api/ophim';
import MovieCard from '../components/MovieCard';
import { MovieItem } from '../types';
import { Link } from 'react-router-dom';

interface FavoritesProps {
    favoriteSlugs: string[];
}

const Favorites: React.FC<FavoritesProps> = ({ favoriteSlugs }) => {
  const [movies, setMovies] = useState<MovieItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchFavorites = async () => {
      if (favoriteSlugs.length === 0) {
          setMovies([]);
          return;
      }
      
      setLoading(true);
      try {
        const moviePromises = favoriteSlugs.map(slug => getMovieDetail(slug));
        const results = await Promise.all(moviePromises);
        const validMovies: MovieItem[] = results
            .filter(r => r.status)
            .map(r => ({
                name: r.movie.name,
                slug: r.movie.slug,
                origin_name: r.movie.origin_name,
                thumb_url: r.movie.thumb_url,
                poster_url: r.movie.poster_url,
                year: r.movie.year
            }));
        setMovies(validMovies);
      } catch (error) {
        console.error('Error fetching favorites:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFavorites();
  }, [favoriteSlugs]);

  return (
    <div className="flex flex-col gap-8 min-h-[50vh]">
      <h2 className="text-2xl font-bold flex items-center gap-3">
        <span className="w-2 h-8 bg-[#ff2e63] rounded-full"></span>
        Phim Yêu Thích Của Bạn
      </h2>

      {loading ? (
        <div className="flex justify-center py-20">
          <div className="w-12 h-12 border-4 border-[#ff2e63] border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : movies.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {movies.map((movie) => (
            <MovieCard key={movie.slug} movie={movie} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white/5 rounded-3xl border border-white/10 flex flex-col items-center gap-6">
           <div className="bg-[#ff2e63]/10 p-6 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-[#ff2e63]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
           </div>
           <div className="max-w-xs">
                <p className="text-lg font-bold">Danh sách trống</p>
                <p className="text-gray-500 text-sm mt-2">Bạn chưa lưu bộ phim nào vào danh sách yêu thích của mình.</p>
           </div>
          <Link to="/" className="bg-[#ff2e63] hover:bg-[#ff2e63]/90 text-white font-bold py-3 px-8 rounded-full transition-all">
            Khám phá phim ngay
          </Link>
        </div>
      )}
    </div>
  );
};

export default Favorites;
