
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface LoginProps {
    onLogin: (username: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() && password.trim()) {
      onLogin(username);
      navigate('/');
    }
  };

  return (
    <div className="max-w-md mx-auto py-12 px-6 bg-white/5 rounded-3xl border border-white/10 shadow-2xl">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold mb-2">{isRegister ? 'Tạo tài khoản' : 'Đăng nhập'}</h2>
        <p className="text-gray-400 text-sm">Chào mừng bạn đến với MOTPHIM</p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-gray-500 uppercase px-4">Tên đăng nhập</label>
          <input
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-5 text-sm focus:outline-none focus:ring-2 focus:ring-[#ff2e63]/50 transition-all"
            placeholder="Nhập tên của bạn"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-gray-500 uppercase px-4">Mật khẩu</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-5 text-sm focus:outline-none focus:ring-2 focus:ring-[#ff2e63]/50 transition-all"
            placeholder="••••••••"
          />
        </div>

        <button
          type="submit"
          className="bg-[#ff2e63] hover:bg-[#ff2e63]/90 text-white font-bold py-4 rounded-2xl mt-4 shadow-lg transition-all"
        >
          {isRegister ? 'Đăng ký ngay' : 'Đăng nhập'}
        </button>
      </form>

      <div className="mt-8 text-center text-sm">
        <span className="text-gray-500">{isRegister ? 'Đã có tài khoản?' : 'Chưa có tài khoản?'} </span>
        <button
          onClick={() => setIsRegister(!isRegister)}
          className="text-[#ff2e63] font-bold hover:underline"
        >
          {isRegister ? 'Đăng nhập tại đây' : 'Đăng ký miễn phí'}
        </button>
      </div>
    </div>
  );
};

export default Login;
