
import React, { useEffect, useState, useLayoutEffect } from 'react';
import { getLatestMovies, getMovieDetail, getMoviesByCategory, getMoviesByType, getImageUrl } from '../api/ophim';
import MovieCard from '../components/MovieCard';
import { MovieItem, MovieDetail } from '../types';
import { HeroSkeleton, SectionSkeleton } from '../components/Skeleton';

const Home: React.FC = () => {
  const [heroMovie, setHeroMovie] = useState<MovieDetail | null>(null);
  const [latestMovies, setLatestMovies] = useState<MovieItem[]>([]);
  const [dubbedMovies, setDubbedMovies] = useState<MovieItem[]>([]);
  const [animeMovies, setAnimeMovies] = useState<MovieItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Use useLayoutEffect to trigger image preload as early as possible
  useLayoutEffect(() => {
    const fetchHero = async () => {
      try {
        // Chủ động tìm phim "Đại Kiếp Án" (The Great Heist) hoặc phim đang hot
        // Slug phim Đại Kiếp Án thường là 'dai-kiep-an' hoặc tương tự
        const heroData = await getMovieDetail('dai-kiep-an').catch(() => null);
        
        if (heroData?.movie) {
          setHeroMovie(heroData.movie);
          // Kỹ thuật Preload ảnh: Chèn link preload vào head ngay khi có URL
          const link = document.createElement('link');
          link.rel = 'preload';
          link.as = 'image';
          link.href = getImageUrl(heroData.movie.poster_url || heroData.movie.thumb_url);
          // @ts-ignore
          link.fetchPriority = 'high';
          document.head.appendChild(link);
        }
      } catch (e) {
        console.error("Hero fetch error", e);
      }
    };
    fetchHero();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [latestRes, dubbedRes, animeRes] = await Promise.all([
          getLatestMovies(1),
          getMoviesByCategory('phim-long-tieng', 1),
          getMoviesByType('hoat-hinh', 1)
        ]);

        const items = latestRes?.items || latestRes?.data?.items || [];
        setLatestMovies(items);

        // Nếu không lấy được phim Đại Kiếp Án riêng, lấy phim đầu tiên trong list làm dự phòng
        if (!heroMovie && items.length > 0) {
            const fallbackHero = await getMovieDetail(items[0].slug);
            if (fallbackHero?.movie) setHeroMovie(fallbackHero.movie);
        }

        setDubbedMovies((dubbedRes?.data?.items || dubbedRes?.items || []).slice(0, 6));
        setAnimeMovies((animeRes?.data?.items || animeRes?.items || []).slice(0, 6));
      } catch (error) {
        console.error('Error fetching list data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [heroMovie]);

  if (loading && !heroMovie) {
    return (
      <div className="flex flex-col gap-24 pb-20">
        <HeroSkeleton />
        <SectionSkeleton title="Đang tải dữ liệu..." />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-24 pb-20 animate-fadeIn">
      {/* Cinematic Hero Section - Hiển thị ngay khi có heroMovie */}
      {heroMovie && (
        <section className="relative h-[85vh] w-full overflow-hidden rounded-[3rem] group shadow-2xl bg-[#0a0a0a]">
          <div className="absolute inset-0 z-0">
             <img 
                src={getImageUrl(heroMovie.poster_url || heroMovie.thumb_url)} 
                className="w-full h-full object-cover brightness-[0.4] group-hover:scale-105 transition-transform duration-[4s] ease-out" 
                alt={heroMovie.name}
                // @ts-ignore
                fetchpriority="high"
             />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent z-10"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-transparent to-transparent z-10"></div>

          <div className="absolute inset-0 z-20 flex flex-col justify-center px-6 md:px-24 gap-8">
              <div className="flex items-center gap-4 animate-slideUp" style={{ animationDelay: '100ms' }}>
                  <div className="h-0.5 w-12 bg-[#ff2e63]"></div>
                  <span className="text-[#ff2e63] text-xs font-black uppercase tracking-[0.4em]">Phim hot nhất</span>
              </div>
              
              <div className="flex flex-col gap-4 max-w-5xl animate-slideUp" style={{ animationDelay: '200ms' }}>
                  <h1 className="text-6xl md:text-[8rem] font-black leading-[0.9] tracking-tighter drop-shadow-2xl text-glow">
                      {heroMovie.name}
                  </h1>
                  <div className="flex items-center gap-6 mt-4">
                      <span className="text-2xl font-medium text-white/40 italic tracking-tight">{heroMovie.origin_name}</span>
                      <div className="h-6 w-[1px] bg-white/10"></div>
                      <span className="bg-[#ff2e63]/10 border border-[#ff2e63]/30 px-4 py-1.5 rounded-full text-[10px] font-black text-[#ff2e63] tracking-widest uppercase">{heroMovie.quality}</span>
                      <span className="bg-white/5 border border-white/10 px-4 py-1.5 rounded-full text-[10px] font-black text-white/60 tracking-widest">{heroMovie.year}</span>
                  </div>
              </div>

              <p className="text-gray-400 max-w-2xl text-sm md:text-base font-medium leading-relaxed opacity-80 line-clamp-3 animate-slideUp" style={{ animationDelay: '300ms' }} dangerouslySetInnerHTML={{ __html: heroMovie.content }}>
              </p>

              <div className="flex items-center gap-6 mt-4 animate-slideUp" style={{ animationDelay: '400ms' }}>
                  <a href={`#/movie/${heroMovie.slug}`} className="bg-[#ff2e63] hover:bg-white text-white hover:text-black font-black py-5 px-14 rounded-2xl shadow-[0_0_50px_rgba(255,46,99,0.3)] transition-all duration-500 flex items-center gap-4 text-xs uppercase tracking-widest group/btn">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 transition-transform group-hover/btn:scale-125" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                       XEM PHIM NGAY
                  </a>
                  <button className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                      </svg>
                  </button>
              </div>
          </div>
        </section>
      )}

      {/* Main Grid Content */}
      <main className="flex flex-col gap-32">
        {dubbedMovies.length > 0 && (
          <section className="animate-slideUp" style={{ animationDelay: '500ms' }}>
              <div className="flex items-end justify-between mb-12 border-b border-white/5 pb-8">
                  <div className="flex flex-col gap-2">
                    <span className="text-[#ff2e63] text-[10px] font-black uppercase tracking-[0.4em]">Premium Content</span>
                    <h2 className="text-4xl font-black tracking-tighter flex items-center gap-4 uppercase">
                        PHIM LỒNG TIẾNG
                    </h2>
                  </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-12">
                {dubbedMovies.map((movie) => (
                  <MovieCard key={`dubbed-${movie.slug}`} movie={movie} />
                ))}
              </div>
          </section>
        )}

        {animeMovies.length > 0 && (
          <section className="animate-slideUp" style={{ animationDelay: '600ms' }}>
              <div className="flex items-end justify-between mb-12 border-b border-white/5 pb-8">
                  <div className="flex flex-col gap-2">
                    <span className="text-blue-500 text-[10px] font-black uppercase tracking-[0.4em]">Visual Masterpieces</span>
                    <h2 className="text-4xl font-black tracking-tighter uppercase">ANIME & HOẠT HÌNH</h2>
                  </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-x-6 gap-y-12">
                {animeMovies.map((movie) => (
                  <MovieCard key={`anime-${movie.slug}`} movie={movie} />
                ))}
              </div>
          </section>
        )}

        <section className="animate-slideUp" style={{ animationDelay: '700ms' }}>
            <div className="flex items-end justify-between mb-12 border-b border-white/5 pb-8">
                <div className="flex flex-col gap-2">
                  <span className="text-yellow-500 text-[10px] font-black uppercase tracking-[0.4em]">Daily Update</span>
                  <h2 className="text-4xl font-black tracking-tighter uppercase">PHIM MỚI CẬP NHẬT</h2>
                </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-12">
              {latestMovies.map((movie) => (
                <MovieCard key={`latest-${movie.slug}`} movie={movie} />
              ))}
            </div>
        </section>
      </main>
    </div>
  );
};

export default Home;
