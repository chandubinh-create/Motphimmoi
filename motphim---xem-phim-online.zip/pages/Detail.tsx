
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getMovieDetail, getImageUrl } from '../api/ophim';
import { MovieDetail, ServerData, EpisodeData } from '../types';
import Player from '../components/Player';

interface DetailProps {
    onToggleFavorite: (slug: string) => void;
    isFavorite: (slug: string) => boolean;
}

const Detail: React.FC<DetailProps> = ({ onToggleFavorite, isFavorite }) => {
  const { slug } = useParams<{ slug: string }>();
  const [movie, setMovie] = useState<MovieDetail | null>(null);
  const [episodes, setEpisodes] = useState<ServerData[]>([]);
  const [currentEpisode, setCurrentEpisode] = useState<EpisodeData | null>(null);
  const [activeServerIdx, setActiveServerIdx] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetail = async () => {
      if (!slug) return;
      setLoading(true);
      try {
        const data = await getMovieDetail(slug);
        if (data?.status && data?.movie) {
          setMovie(data.movie);
          const epList = data?.episodes || [];
          setEpisodes(epList);
          if (epList.length > 0 && epList[0]?.server_data?.length > 0) {
            setCurrentEpisode(epList[0].server_data[0]);
          }
        }
      } catch (error) {
        console.error('Error fetching movie detail:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchDetail();
    window.scrollTo(0, 0);
  }, [slug]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-6">
        <div className="w-16 h-16 border-4 border-[#ff2e63]/20 border-t-[#ff2e63] rounded-full animate-spin"></div>
        <p className="text-gray-500 font-black uppercase tracking-[0.2em] text-xs">Cấu hình rạp phim...</p>
      </div>
    );
  }

  if (!movie) return null;
  const isFavorited = slug ? isFavorite(slug) : false;

  return (
    <div className="flex flex-col gap-12 pb-24">
      {/* Immersive Player Area */}
      <section className="flex flex-col gap-8">
        {currentEpisode ? (
            <div className="flex flex-col gap-8">
                <div className="relative group">
                    <Player src={currentEpisode.link_m3u8 || currentEpisode.link_embed} />
                    <div className="absolute -inset-1 bg-gradient-to-r from-[#ff2e63]/20 to-blue-500/20 rounded-3xl blur-2xl opacity-30 pointer-events-none"></div>
                </div>
                
                <div className="flex flex-col lg:flex-row justify-between items-start gap-8 px-2">
                    <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-3">
                            <span className="bg-[#ff2e63] text-white text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest">Đang phát</span>
                            <span className="text-gray-500 text-xs font-bold tracking-widest uppercase">Tập {currentEpisode.name} • {movie.lang}</span>
                        </div>
                        <h1 className="text-4xl md:text-6xl font-black tracking-tighter leading-none">{movie.name}</h1>
                        <p className="text-xl text-white/40 font-medium italic tracking-tight">{movie.origin_name}</p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                        <button 
                            onClick={() => slug && onToggleFavorite(slug)}
                            className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-xs tracking-widest transition-all duration-300 shadow-xl ${isFavorited ? 'bg-[#ff2e63] text-white shadow-[#ff2e63]/20' : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'}`}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill={isFavorited ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                            </svg>
                            {isFavorited ? 'TRONG BỘ SƯU TẬP' : 'LƯU VÀO YÊU THÍCH'}
                        </button>
                    </div>
                </div>
            </div>
        ) : (
            <div className="aspect-video bg-white/5 rounded-[2.5rem] flex items-center justify-center border border-white/5 border-dashed">
                <p className="text-gray-500 font-black uppercase tracking-[0.3em] text-xs">Phim đang chờ tải dữ liệu...</p>
            </div>
        )}
      </section>

      <div className="grid lg:grid-cols-[1fr_400px] gap-12">
        {/* Main Content */}
        <div className="flex flex-col gap-12">
            {/* Premium Episode Selection */}
            <div className="bg-[#0d0d0d] border border-white/5 p-8 md:p-12 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-[#ff2e63]/5 blur-[100px] rounded-full"></div>
                
                <h2 className="text-2xl font-black mb-10 flex items-center gap-4 tracking-tighter">
                    <span className="w-2 h-8 bg-[#ff2e63] rounded-full shadow-[0_0_15px_#ff2e63]"></span>
                    CHỌN TẬP PHIM
                </h2>
                
                {episodes.map((server, idx) => (
                    <div key={`server-${idx}`} className="flex flex-col gap-6 mb-12 last:mb-0">
                        <div className="flex items-center gap-4 text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">
                             <div className="w-2 h-2 rounded-full bg-white/20"></div>
                             SERVER: <span className={server.server_name.includes('Lồng Tiếng') ? 'text-green-500' : 'text-[#ff2e63]'}>{server.server_name}</span>
                        </div>
                        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3">
                            {server.server_data.map((ep, epIdx) => (
                                <button
                                    key={`ep-${epIdx}`}
                                    onClick={() => {
                                        setActiveServerIdx(idx);
                                        setCurrentEpisode(ep);
                                        window.scrollTo({ top: 0, behavior: 'smooth' });
                                    }}
                                    className={`py-3 rounded-xl text-xs font-black transition-all border ${currentEpisode?.slug === ep.slug && activeServerIdx === idx ? 'bg-[#ff2e63] border-[#ff2e63] text-white shadow-[0_0_20px_rgba(255,46,99,0.3)]' : 'bg-white/5 border-white/5 text-gray-500 hover:bg-white/10 hover:text-white'}`}
                                >
                                    {ep.name}
                                </button>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            <div className="flex flex-col gap-8">
                <h3 className="text-3xl font-black tracking-tighter uppercase">Giới thiệu phim</h3>
                <div className="text-gray-400 text-base leading-[1.8] font-medium bg-white/5 p-10 rounded-[2.5rem] border border-white/5" dangerouslySetInnerHTML={{ __html: movie.content }} />
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
                {[
                    { label: 'Dàn diễn viên', value: movie.actor.join(', ') },
                    { label: 'Đạo diễn', value: movie.director.join(', ') },
                    { label: 'Thể loại', value: movie.category.map(c => c.name).join(', ') },
                    { label: 'Quốc gia', value: movie.country.map(c => c.name).join(', ') }
                ].map((item, idx) => (
                    <div key={idx} className="bg-white/5 p-8 rounded-3xl border border-white/5 group hover:bg-white/10 transition-all">
                        <span className="text-[10px] text-gray-600 font-black uppercase tracking-[0.2em] mb-2 block">{item.label}</span>
                        <span className="text-sm font-bold text-white/80 leading-relaxed">{item.value || 'Đang cập nhật'}</span>
                    </div>
                ))}
            </div>
        </div>

        {/* Info Sidebar */}
        <aside className="flex flex-col gap-10">
            <div className="bg-[#0d0d0d] border border-white/5 p-8 rounded-[2.5rem] flex flex-col gap-10 shadow-2xl">
                 <div className="relative group overflow-hidden rounded-2xl">
                    <img 
                        src={getImageUrl(movie.thumb_url)} 
                        alt={movie.name} 
                        className="w-full transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                </div>

                <div className="flex flex-col gap-6">
                    {[
                        { label: 'Trạng thái', value: movie.episode_current, highlight: true },
                        { label: 'Độ dài', value: movie.time },
                        { label: 'Chất lượng', value: movie.quality, badge: 'bg-green-500/10 text-green-500 border-green-500/20' },
                        { label: 'Ngôn ngữ', value: movie.lang, badge: 'bg-blue-500/10 text-blue-500 border-blue-500/20' },
                        { label: 'Phát hành', value: movie.year }
                    ].map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center pb-4 border-b border-white/5 last:border-0 last:pb-0">
                            <span className="text-gray-600 text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                            {item.badge ? (
                                <span className={`text-[10px] font-black px-3 py-1 rounded-lg border ${item.badge}`}>{item.value}</span>
                            ) : (
                                <span className={`text-xs font-black ${item.highlight ? 'text-[#ff2e63]' : 'text-white'}`}>{item.value}</span>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {movie.trailer_url && (
                <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/5 flex flex-col gap-6">
                    <h3 className="font-black text-xs uppercase tracking-[0.3em] text-gray-600">Offical Trailer</h3>
                    <div className="aspect-video bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                        <iframe 
                            src={movie.trailer_url.replace('watch?v=', 'embed/')} 
                            className="w-full h-full"
                            title="Trailer"
                            frameBorder="0"
                            allowFullScreen
                        ></iframe>
                    </div>
                </div>
            )}
        </aside>
      </div>
    </div>
  );
};

export default Detail;
