
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

interface HeaderProps {
    user: { username: string; isLoggedIn: boolean };
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm.trim())}`);
      setSearchTerm('');
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 px-4 md:px-12 py-4 ${isScrolled ? 'bg-black/60 backdrop-blur-xl border-b border-white/5 py-3' : 'bg-transparent'}`}>
      <div className="max-w-[1600px] mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-12">
          <Link to="/" className="group flex items-center gap-2">
            <div className="w-10 h-10 bg-[#ff2e63] rounded-xl flex items-center justify-center rotate-3 group-hover:rotate-12 transition-transform duration-500 shadow-[0_0_20px_rgba(255,46,99,0.4)]">
                <span className="text-white font-black text-xl italic">M</span>
            </div>
            <span className="text-2xl font-black tracking-tighter hidden sm:block">
                MOT<span className="text-[#ff2e63] text-glow">PHIM</span>
            </span>
          </Link>
          
          <nav className="hidden lg:flex gap-8 text-[11px] font-black uppercase tracking-[0.2em] text-white/50">
            <Link to="/" className="hover:text-white transition-colors relative group">
                Trang chủ
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#ff2e63] transition-all group-hover:w-full"></span>
            </Link>
            <Link to="/category/phim-le" className="hover:text-white transition-colors relative group">
                Phim Lẻ
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#ff2e63] transition-all group-hover:w-full"></span>
            </Link>
            <Link to="/category/phim-bo" className="hover:text-white transition-colors relative group">
                Phim Bộ
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#ff2e63] transition-all group-hover:w-full"></span>
            </Link>
            {user.isLoggedIn && (
              <Link to="/favorites" className="hover:text-white transition-colors relative group">
                  Bộ sưu tập
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#ff2e63] transition-all group-hover:w-full"></span>
              </Link>
            )}
          </nav>
        </div>

        <div className="flex items-center gap-6 flex-1 justify-end max-w-2xl">
          <form onSubmit={handleSearch} className="relative w-full max-w-md group">
            <input
              type="text"
              placeholder="Khám phá kho phim..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-2.5 px-6 text-xs font-medium focus:outline-none focus:bg-white/10 focus:border-[#ff2e63]/50 focus:ring-4 focus:ring-[#ff2e63]/10 transition-all placeholder:text-gray-600"
            />
            <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-[#ff2e63] transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </form>

          <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>

          {user.isLoggedIn ? (
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex flex-col items-end">
                  <span className="text-[10px] text-gray-500 font-black uppercase tracking-widest">Thành viên</span>
                  <span className="text-xs font-bold">{user.username}</span>
              </div>
              <button 
                  onClick={onLogout}
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-red-500/20 hover:border-red-500/50 transition-all text-red-500"
                  title="Đăng xuất"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          ) : (
            <Link 
              to="/login"
              className="bg-white text-black hover:bg-[#ff2e63] hover:text-white text-[11px] font-black px-8 py-3 rounded-2xl transition-all duration-300 uppercase tracking-widest shadow-xl shadow-white/5"
            >
              Đăng nhập
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
